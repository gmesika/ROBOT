package javaapplication1;

import java.awt.Component;
import java.lang.ref.WeakReference;
import java.util.Calendar;
import java.util.Enumeration;

import javax.swing.JFrame;
import javax.swing.tree.DefaultMutableTreeNode;

public class ComponentTreeNode extends DefaultMutableTreeNode
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4889325456371607730L;

	private int componentHashCode;
	private int componentIndex;
	private String nodeDescription; 
	private WeakReference<Component> weakReferenceToComponent;
	private long detectedTime;
	
	public ComponentTreeNode(Component component, int componentIndex) {
		super();
		this.componentIndex = componentIndex;
		this.componentHashCode = component.hashCode();
		nodeDescription = getNodeDescription(component, componentIndex);		
		this.setUserObject(nodeDescription);
		weakReferenceToComponent = new WeakReference<Component>(component);
		detectedTime = Calendar.getInstance().getTimeInMillis();
	}
	
	public ComponentTreeNode(String description) {
		super(description);
	}

	public int getComponentHashCode() {
		return componentHashCode;
	}
	public void setComponentHashCode(int hashCode) {
		this.componentHashCode = hashCode;
	}
	public int getIndex() {
		return componentIndex;
	}
	public void setIndex(int index) {
		this.componentIndex = index;
	}
	public String getNodeDescription() {
		return nodeDescription;
	}
	public void setNodeDescription(String nodeDescription) {
		this.nodeDescription = nodeDescription;
		this.setUserObject(nodeDescription);
	}
	
	//TODO change so component and componentIndex will be as parameter
	public String getNodeDescription(Component component, int index)
	{	
		String title = "";
		if (component instanceof JFrame)
		{
			title = ((JFrame)component).getTitle();
		}
		
		String simpleClassName = component.getClass().getSimpleName();
		if (simpleClassName.equals(""))
		{
			simpleClassName = component.getClass().getName().toString();
		}
		String componentName;
		if (title.equals(""))
			componentName = component.getName();
		else
			componentName = title;
		
		return simpleClassName + "(" + componentName + ")[" + index + "]";
	}
		
	ComponentTreeNode getComponentTreeNodeByComponent(Component component, int componentIndex)
	{
		Enumeration e = this.children();
		while(e.hasMoreElements())
		{			
			ComponentTreeNode node = (ComponentTreeNode) e.nextElement();
			String componentCurrentDescription = node.getUserObject().toString();
			String componentDescription = node.getNodeDescription(component, componentIndex);
			if (componentCurrentDescription.equals(componentDescription))
			{
				return node;
			}			
		}  
		return null;
	}

	public String getNodeDetails()
	{
		StringBuffer nodeDetails = new StringBuffer();
		nodeDetails.append("componentHashCode: ");
		nodeDetails.append(componentHashCode);
		nodeDetails.append("\n");
		nodeDetails.append("componentIndex: ");
		nodeDetails.append(componentIndex);
		nodeDetails.append("\n");
		nodeDetails.append("nodeDescription: ");
		nodeDetails.append(nodeDescription);
		nodeDetails.append("\n");
		nodeDetails.append("has Weak Reference: ");
		nodeDetails.append(weakReferenceToComponent.get()!=null);
		nodeDetails.append("\n");
		
		return nodeDetails.toString();
	}

	public long getDetectedTime() {
		return detectedTime;
	}

	public WeakReference<Component> getWeakReferenceToComponent() {
		return weakReferenceToComponent;
	}
	
}
