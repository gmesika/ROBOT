/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

/**
 *
 * @author GUYMES
 */
public class Inspector extends javax.swing.JFrame
implements MonitoredWindowListener,TreeSelectionListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9115828458408165896L;
	
	Timer timer;
	private boolean showRefreshButton = false;
	private int windowsSyncIntervalms = 1000;
	private int windowsSyncInitialDelayms = 0;
	private boolean executeSyncOnNextTimer = true;
	private boolean syncPausedByKey = false;
	private boolean stopSync = false;
	private boolean currentlySyncing = false;

	private final List<MonitoredEventsListener> monitoredEventsListener = new ArrayList<MonitoredEventsListener>();

	private static Inspector inspector;
	private static RobotController robotic;

	private DefaultTreeModel treeModel;
	private ComponentTreeNode root;
	private DefaultListModel model;

	private boolean listenToInputEvents = false;

	private long lastKeyboardClickTimestamp;
	private long lastMouseClickTimestamp;

	/**
	 * Creates new form NewJFrame
	 * @throws InterruptedException 
	 * @throws InvocationTargetException 
	 */
	public Inspector()  {

		inspector = this;		

		initComponents();
		Container contentPane = this.getContentPane();
		contentPane.setLayout(new GridLayout());

		this.setVisible(true);

		SwingUtils.invoke(new Runnable() {
			public void run() {
				robotic = new RobotController();
			}
		});		

		setInspectionTreeProperties();

		timer = new Timer();
		
		MonitoredWindows.getInstance().registerForWindowsNotifictions(this);	

		attachToInputs();						

		this.setTitle("Inspector");				
	}



	private void setInspectionTreeProperties()
	{
		root = new ComponentTreeNode("Windows");
		this.treeModel = new DefaultTreeModel(root);
		treeModel.addTreeModelListener(new InspectionTreeModelListener());

		SwingUtils.invoke(new Runnable(){

			@Override
			public void run()
			{
				model = new DefaultListModel();
				getInspectionTree().setModel(treeModel);
				getInspectionTree().getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
				getInspectionTree().addTreeSelectionListener(Inspector.getInstance());
			}

		});				
	}

	public static Inspector getInstance()
	{
		return inspector;
	}

	public void attachToInputs()
	{
		handleMouseEvents();
		handleKeyboardEvents();
	}

	public void resetLastMouseClickTimestamp()
	{
		lastMouseClickTimestamp = 0;
	}

	public void resetLastKeyboardClickTimestamp()
	{
		lastKeyboardClickTimestamp = 0;
	}

	private void completeOneFullWindowSync()
	{	
		//TODO deadlock ahead
		// if SwingUtils invoke will be to wait
		// this will hang
		if (currentlySyncing)
		{
			stopSync=true;
			int waiting = 0;
			while (currentlySyncing)
			{
				try {
					waiting = waiting + 100;
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				// wait for current sync to be done
				// if they are running in same thread
				// this loop will never be executed
				
				if (waiting > 1000)
					break;
			}
		}			

		// Have to complete at least one full sync 
		// after clicking on control so will be sure that if new
		// handle was created then it will be displayed in window

		stopSync=false;
		sync();
		stopSync=true;			

	}

	private void handleMouseEvents()
	{
		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener()
		{
			@Override
			public void eventDispatched(AWTEvent event) 
			{
				if (listenToInputEvents)
				{
					MouseEvent mouseEvent = (MouseEvent)event;

					if (mouseEvent.getID() != MouseEvent.MOUSE_ENTERED 
							&& mouseEvent.getID() != MouseEvent.MOUSE_EXITED 
							&& mouseEvent.getID() != MouseEvent.MOUSE_RELEASED)
					{
						completeOneFullWindowSync();

						if (isInRestrictedList(mouseEvent.getSource().hashCode()))
						{
							// maybe it is not a Component class
							stopSync = false;
							return;			
						}

						Component component = (Component) mouseEvent.getSource();
						Component componentTopParent = SwingUtilities.getWindowAncestor(component);
						if (componentTopParent == null)
							componentTopParent = component;

						if (isInRestrictedList(componentTopParent.hashCode()))
						{
							// maybe window was not loaded yet
							stopSync = false;
							return;			
						}

						JavaApplication1.writeToLog(event.toString());
						if (lastMouseClickTimestamp == 0)
							lastMouseClickTimestamp = Calendar.getInstance().getTimeInMillis();									

						try {
							JavaApplication1.writeToLog("Mouse location on screen X: " + component.getLocationOnScreen().x
									+ " Y: " + component.getLocationOnScreen().y);	
						} catch (Exception e) {
						}

						if (componentTopParent != null)
						{
							ComponentTreeNode rootComponentTreeNode = getComponentTreeNodeByComponent(root, componentTopParent, false);
							final ComponentTreeNode componentTreeNode = getComponentTreeNodeByComponent(rootComponentTreeNode, component, true);
							if (componentTreeNode != null)
							{
								final TreePath treePath = new TreePath(componentTreeNode.getPath());;
								SwingUtils.invoke(new Runnable() {

									@Override
									public void run() {																		
										if (highlightSelectedNode.isSelected() == true)
										{
											getInspectionTree().setSelectionPath(treePath);
										}
									}
								});

								monitoredMouseEvent(treePath, event, (int) (Calendar.getInstance().getTimeInMillis() - lastMouseClickTimestamp));							
								lastMouseClickTimestamp = Calendar.getInstance().getTimeInMillis();
							}						
						}

						component=null;
						componentTopParent=null;
						System.gc();

						stopSync = false;
					}										
				}				
			}        	
		},AWTEvent.MOUSE_EVENT_MASK);		
	}

	public boolean isInRestrictedList(int hashCode)
	{
		if (this.hashCode() == hashCode || RobotController.getInstance().hashCode() == hashCode || RobotController.getInstance().trayIcon.hashCode() == hashCode)
			return true;

		return false;
	}
	//	
	//	public ComponentTreeNode getComponentTreeNodeByDescriptionFollowingPath(ComponentTreeNode parentComponentTreeNode, String[] path, int index)
	//	{
	//		String description = path[index];
	//		if (parentComponentTreeNode.getNodeDescription().)
	//			
	//		Enumeration e =  parentComponentTreeNode.children();
	//		while(e.hasMoreElements())
	//		{	
	//			ComponentTreeNode node = (ComponentTreeNode) e.nextElement();
	//			
	//			
	//			if (node.getNodeDescription().equals(description))
	//			{
	//				return node;
	//			}
	//		}
	//		return null;
	//	}

	public ComponentTreeNode getComponentTreeNodeByNodeDescription(ComponentTreeNode parentComponentTreeNode, String description)
	{
		if (parentComponentTreeNode == null)
		{
			JavaApplication1.writeToLog("Failed to find: " + description);
			return null;
		}

		Enumeration e =  parentComponentTreeNode.children();
		StringBuffer childrens = new StringBuffer();
		childrens.append("Childrens of: ");
		childrens.append(parentComponentTreeNode.getNodeDescription());
		childrens.append(" are: ");
		while(e.hasMoreElements())
		{	
			ComponentTreeNode node = (ComponentTreeNode) e.nextElement();
			childrens.append(node.getNodeDescription());
			childrens.append(" , ");
		}
		JavaApplication1.writeToLog(childrens.toString());

		e =  parentComponentTreeNode.children();
		while(e.hasMoreElements())
		{	
			ComponentTreeNode node = (ComponentTreeNode) e.nextElement();
			if (node.getNodeDescription().equals(description))
			{
				return node;
			}
		}

		return null;
	}	

	ComponentTreeNode getComponentTreeNodeByComponent(ComponentTreeNode parent, Component component, boolean deepSearch)
	{
		Enumeration e = parent.children();
		while(e.hasMoreElements())
		{	
			ComponentTreeNode node = (ComponentTreeNode) e.nextElement();
			if (deepSearch)
			{
				ComponentTreeNode returnedNode = getComponentTreeNodeByComponent(node, component, deepSearch);
				if (returnedNode != null)
				{
					return returnedNode;
				}
			}
			if (node.getComponentHashCode() == component.hashCode())
			{
				return node;
			}				
		}  
		return null;
	}

	private ComponentTreeNode getComponentTreeNodeByComponentByHashCode(ComponentTreeNode parent, int componentHashCode)
	{
		Enumeration e = parent.children();
		while(e.hasMoreElements())
		{	
			ComponentTreeNode node = (ComponentTreeNode) e.nextElement();					
			if (node.getComponentHashCode() == componentHashCode)
			{
				return node;
			}				
		}  
		return null;
	}

	public Component getComponentByComponentTreeNode(ComponentTreeNode componentTreeNode)
	{
		ComponentTreeNode rootWindowComponentTreeNode = (ComponentTreeNode) componentTreeNode.getPath()[1];		
		int rootWindowHashCode = rootWindowComponentTreeNode.getComponentHashCode();
		Component window = MonitoredWindows.getInstance().getNativeWindow(String.valueOf(rootWindowHashCode), new StringBuffer());
		Component component = getComponentByHash(window, String.valueOf(componentTreeNode.getComponentHashCode()));
		return component;		
	}		

	public Component getComponentByHash(Component topComponent, String hash)
	{
		if (String.valueOf(topComponent.hashCode()).equals(hash))
			return topComponent;

		if (topComponent instanceof Container)
		{
			Component[] components = ((Container)topComponent).getComponents();
			if (components != null)
			{
				Component targetComponent;
				for (Component component : components)
				{
					if (String.valueOf(component.hashCode()).equals(hash))
					{
						return component;
					}

					targetComponent = getComponentByHash(component, hash);
					if (targetComponent != null)
					{
						return targetComponent;
					}

				}
			}
		}
		else
		{
			JavaApplication1.writeToLog("getComponentByHash: it is not a container object. i.e.: com.jniwrapper.win32.ie, class: " + topComponent.getClass().toString());
		}

		return null;
	}


	// method was replaced by SwingUtilities.getWindowAncestor(component);
	// 
	// did not deleted yet to make sure that Swing is working properly
	//
	//	private Component getComponentTopParent(Component component, StringBuffer path)
	//	{
	//		if (component.getClass().getSimpleName().equals("HeavyWeightWindow") ||
	//				component.getClass().getSimpleName().equals("JDialog") )
	//		{
	//			return component;
	//		}
	//		if (component.getParent() == null)
	//		{
	//			return component;
	//		}
	//		Component topParent = null;
	//		if (component.getParent() != null)
	//		{
	//			if (path !=null)
	//				path.insert(0,component.getParent().getName() + "/");
	//			
	//			topParent = getComponentTopParent(component.getParent(), path);
	//		}
	//		return topParent;
	//	}	

	private void handleKeyboardEvents()
	{
		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener()
		{
			public void eventDispatched(AWTEvent event)
			{
				KeyEvent keyEvent = (KeyEvent) event;

				// CTRL+A code is here so it will execute on any window opened - including inspector
				if (keyEvent.isControlDown() && keyEvent.getKeyCode() == KeyEvent.VK_A)
				{
					if (executeSyncOnNextTimer == true)
					{
						currentOperationLabel.setText("Timer refresh are OFF!");
						executeSyncOnNextTimer = false;
						syncPausedByKey = true;
					}						
					else
					{
						if (! showRefreshButton && ! executeSyncOnNextTimer)
						{
							currentOperationLabel.setText("Timer refresh are ON.");
							executeSyncOnNextTimer = true;
							syncPausedByKey = false;
						}
					}
					setupTimer();
				}

				if (listenToInputEvents)
				{
					if (event.getID() != KeyEvent.KEY_TYPED 
							&& event.getID() != KeyEvent.KEY_RELEASED)
					{
						completeOneFullWindowSync();

						Component component = (Component) keyEvent.getSource();
						Component componentTopParent = SwingUtilities.getWindowAncestor(component);
						if (componentTopParent == null)
							componentTopParent = component;

						if (isInRestrictedList(componentTopParent.hashCode()))
						{
							stopSync = false;
							return;			
						}

						JavaApplication1.writeToLog(event.toString());
						if (lastKeyboardClickTimestamp == 0)
							lastKeyboardClickTimestamp = Calendar.getInstance().getTimeInMillis();

						// Only KEY_PRESSED is valid because it records the actual keycode
						if (event.getSource() instanceof JDialog)
						{
							if (((JDialog)event.getSource()).getName().equals("ErrorDialog"))
							{
								listenToInputEvents = false;
								stopSync = true;	
								return;
							}
						}

						if (componentTopParent != null)
						{
							ComponentTreeNode rootComponentTreeNode = getComponentTreeNodeByComponent(root, componentTopParent, false);
							final ComponentTreeNode componentTreeNode = getComponentTreeNodeByComponent(rootComponentTreeNode, component, true);
							if (componentTreeNode != null)
							{
								final TreePath treePath = new TreePath(componentTreeNode.getPath());;
								SwingUtils.invoke(new Runnable() {

									@Override
									public void run() {																		
										if (highlightSelectedNode.isSelected() == true)
										{
											getInspectionTree().setSelectionPath(treePath);
										}
									}
								});

								monitoreKeyboardEvent(treePath, event, (int) (Calendar.getInstance().getTimeInMillis() - lastKeyboardClickTimestamp));						
								lastKeyboardClickTimestamp = Calendar.getInstance().getTimeInMillis();
							}						
						}

						component=null;
						componentTopParent=null;
						System.gc();

						stopSync = false;																		
					}										
				}				
			}
		}
		,KeyEvent.KEY_EVENT_MASK);               
	}
	
	public void setupTimer()
	{
		if (showRefreshButton)
		{
			Refresh.setVisible(true);
		}
		else
		{
			Refresh.setVisible(false);
			timer.schedule(new TimerTask() {
				@Override
				public void run() {
					if (executeSyncOnNextTimer)
					{
						sync();						
					}
				}
			}, windowsSyncInitialDelayms, windowsSyncIntervalms);
		}

	}

	public void sync()
	{		
		if (!currentlySyncing)
			if (! stopSync && ! syncPausedByKey)
			{
				currentlySyncing = true;
				MonitoredWindows.getInstance().syncWindows();
				currentlySyncing = false;
			}

	}

	//	private String getTopMostParentHashCode(Component obj)
	//	{
	//		if (obj.getParent() != null)
	//			return getTopMostParentHashCode(obj.getParent());
	//		else
	//			return String.valueOf(obj.hashCode());		
	//	}



	public void valueChanged(TreeSelectionEvent e) {

		ComponentTreeNode selectednode;
		//Returns the last path element of the selection.
		//This method is useful only when the selection model allows a single selection.
		selectednode = (ComponentTreeNode) getInspectionTree().getLastSelectedPathComponent();

		if (selectednode == null)
			//Nothing is selected.     
			return;

		Object nodeInfo = selectednode.getUserObject();  
		String nodeText = nodeInfo.toString();
		if (nodeText.equals("Windows"))
			return;

		JavaApplication1.writeToLog(selectednode.getNodeDetails());

		circleComponent(selectednode);    		
	}       

	private void listProperties(Object obj)
	{
		//jList2.removeAll();
		DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

		while (model.getRowCount() > 0)
		{
			model.removeRow(0);
		}

		Field[] fields = obj.getClass().getDeclaredFields();
		//List properties = new ArrayList();
		for (Field field : fields) 
		{
			String fieldValue;
			//String fieldText = Modifier.toString(field.getModifiers()) + " " + field.getType().getSimpleName() + " " + field.getName();
			field.setAccessible(true);
			try {
				fieldValue = String.valueOf(field.get(obj));
				//fieldText  = fieldText + " " + field.get(container);
			} catch (IllegalArgumentException e) {
				fieldValue = "unable to obtain value!";
				//fieldText  = fieldText + " unable to obtain value!";
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				fieldValue = "unable to obtain value!";
				//fieldText  = fieldText + " unable to obtain value!";
				e.printStackTrace();
			}
			model.addRow(new Object[]{Modifier.toString(field.getModifiers()), field.getType().getSimpleName(), field.getName(), fieldValue});			

			//properties.add(fieldText);
		}
		//jList2.setListData(properties.toArray());
	}

	private String getTopWindowDescription(TreePath treePath)
	{
		if (treePath.getParentPath() != null)
		{
			if (treePath.getParentPath().getParentPath() == null)
			{
				return treePath.getLastPathComponent().toString();
			}
			else
			{
				return getTopWindowDescription(treePath.getParentPath());
			}
		}
		return null;
	}


	public int getIndex(String componentDescription)
	{
		int startIndex = componentDescription.indexOf("[");
		int endIndex = componentDescription.indexOf("]");
		int componentIndex = Integer.parseInt(componentDescription.substring(startIndex, endIndex));
		return componentIndex;
	}

	private void circleComponent(ComponentTreeNode componentTreeNode)
	{
		Component component = getComponentByComponentTreeNode(componentTreeNode);	

		if (component instanceof JComponent)
		{
			circleJComponent((JComponent) component);							  	
			listProperties(component);				
		}    		
		component=null;
		System.gc();
	}

	private void circleJComponent(final JComponent component)
	{
		SwingWorker worker = new SwingWorker<Void, Void>() {
			@Override
			public Void doInBackground() {
				component.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.RED));
				try {
					Thread.sleep(200);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				component.setBorder(null);     
				try {
					Thread.sleep(200);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				component.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.RED));
				try {
					Thread.sleep(200);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				component.setBorder(null);
				return null;
			}

			@Override
			public void done() {
			}
		};
		worker.execute();
	}


	JTree jTree1;



	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jPanel2 = new javax.swing.JPanel();
		jSplitPane1 = new javax.swing.JSplitPane();
		jScrollPane2 = new javax.swing.JScrollPane();
		inspectionTree = new javax.swing.JTree();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTable1 = new javax.swing.JTable();
		jPanel3 = new javax.swing.JPanel();
		currentOperationLabel = new javax.swing.JLabel();
		Refresh = new javax.swing.JButton();
		jScrollPane3 = new javax.swing.JScrollPane();
		jList1 = new javax.swing.JList();
		currentOperationLabel1 = new javax.swing.JLabel();
		highlightSelectedNode = new javax.swing.JCheckBox();
		mainMenuBar = new javax.swing.JMenuBar();
		fileMenu = new javax.swing.JMenu();
		exitMenuItem = new javax.swing.JMenuItem();
		jMenu2 = new javax.swing.JMenu();

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(
				jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 100, Short.MAX_VALUE)
				);
		jPanel1Layout.setVerticalGroup(
				jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 100, Short.MAX_VALUE)
				);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setFocusCycleRoot(false);
		setName("swingInspector"); // NOI18N
		getContentPane().setLayout(new java.awt.FlowLayout());

		jPanel2.setMaximumSize(new java.awt.Dimension(32767, 300));

		jSplitPane1.setDividerLocation(200);

		jScrollPane2.setViewportView(inspectionTree);

		jSplitPane1.setLeftComponent(jScrollPane2);

		jTable1.setModel(new javax.swing.table.DefaultTableModel(
				new Object [][] {

				},
				new String [] {
						"Modifier", "Type", "Name", "Value"
				}
				) {
			boolean[] canEdit = new boolean [] {
					false, false, false, false
			};

			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return canEdit [columnIndex];
			}
		});
		jScrollPane1.setViewportView(jTable1);

		jSplitPane1.setRightComponent(jScrollPane1);

		jPanel3.setMaximumSize(new java.awt.Dimension(32767, 70));
		jPanel3.setName("xxx"); // NOI18N

		currentOperationLabel.setText("Nothing is happening yet...");

		Refresh.setText("Refresh");
		Refresh.setName("xxx"); // NOI18N
		Refresh.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				RefreshActionPerformed(evt);
			}
		});

		jList1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		jScrollPane3.setViewportView(jList1);

		currentOperationLabel1.setText("Windows history:");

		highlightSelectedNode.setLabel("Highlight mouse selected tree node");
		highlightSelectedNode.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				highlightSelectedNodeActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(
				jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel3Layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel3Layout.createSequentialGroup()
										.addComponent(currentOperationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 755, javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(Refresh))
										.addGroup(jPanel3Layout.createSequentialGroup()
												.addComponent(currentOperationLabel1)
												.addGap(0, 0, Short.MAX_VALUE)))
												.addContainerGap())
												.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
														.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addComponent(highlightSelectedNode)
														.addGap(229, 229, 229))
														.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
																.addGroup(jPanel3Layout.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addContainerGap(430, Short.MAX_VALUE)))
				);
		jPanel3Layout.setVerticalGroup(
				jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel3Layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(currentOperationLabel)
								.addComponent(Refresh))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(currentOperationLabel1)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addComponent(highlightSelectedNode)
								.addContainerGap(59, Short.MAX_VALUE))
								.addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
												.addContainerGap(64, Short.MAX_VALUE)
												.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
												.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
				);

		currentOperationLabel.getAccessibleContext().setAccessibleName("currentOperationLabel");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(
				jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 896, Short.MAX_VALUE)
				.addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				);
		jPanel2Layout.setVerticalGroup(
				jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup()
						.addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 463, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
				);

		getContentPane().add(jPanel2);

		fileMenu.setText("File");
		fileMenu.addMenuKeyListener(new javax.swing.event.MenuKeyListener() {
			public void menuKeyPressed(javax.swing.event.MenuKeyEvent evt) {
				//fileMenuMenuKeyPressed(evt);
			}
			public void menuKeyReleased(javax.swing.event.MenuKeyEvent evt) {
			}
			public void menuKeyTyped(javax.swing.event.MenuKeyEvent evt) {
			}
		});

		exitMenuItem.setText("Exit");
		exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitMenuItemActionPerformed(evt);
			}
		});
		fileMenu.add(exitMenuItem);

		mainMenuBar.add(fileMenu);

		jMenu2.setText("Edit");
		mainMenuBar.add(jMenu2);

		setJMenuBar(mainMenuBar);

		pack();
	}// </editor-fold>//GEN-END:initComponents

	private void RefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshActionPerformed
		sync();
	}//GEN-LAST:event_RefreshActionPerformed

	private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
		System.exit(0);
	}//GEN-LAST:event_exitMenuItemActionPerformed

	private void highlightSelectedNodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_highlightSelectedNodeActionPerformed

	}//GEN-LAST:event_highlightSelectedNodeActionPerformed

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
		/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
		 * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Inspector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Inspector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Inspector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Inspector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		//</editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Inspector().setVisible(true);
			}
		});

	}	

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton Refresh;
	private javax.swing.JLabel currentOperationLabel;
	private javax.swing.JLabel currentOperationLabel1;
	private javax.swing.JMenuItem exitMenuItem;
	private javax.swing.JMenu fileMenu;
	private javax.swing.JCheckBox highlightSelectedNode;
	private javax.swing.JTree inspectionTree;
	private javax.swing.JList jList1;
	private javax.swing.JMenu jMenu2;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JSplitPane jSplitPane1;
	private javax.swing.JTable jTable1;
	private javax.swing.JMenuBar mainMenuBar;
	// End of variables declaration//GEN-END:variables

	@Override
	public void monitoredWindowAdded(final String hash) 
	{
		if (isInRestrictedList(Integer.valueOf(hash)))
			return;
						
		StringBuffer windowIndex = new StringBuffer();
		Window window = MonitoredWindows.getInstance().getNativeWindow(hash, windowIndex);			

		//TODO change this
		if (window.toString().equals("java.awt.Frame[frame0,0,0,132x38,invalid,hidden,layout=java.awt.BorderLayout,title=PopupMessageWindow,resizable,normal]"))
			return;
		
		updateCurrentOperationsLabel("New window opened. Hash: " + hash);
		
		final ComponentTreeNode addedWindowTreeNode = new ComponentTreeNode(window, Integer.parseInt(windowIndex.toString()));
		SwingUtils.invoke(new Runnable() {

			@Override
			public void run() {
				treeModel.insertNodeInto(addedWindowTreeNode, root, root.getChildCount());		
				TreePath treePath = new TreePath(root);
				if (!inspectionTree.isExpanded(treePath))
				{
					inspectionTree.expandPath(treePath);
				}	
			}
		});			

		addUpdateRemoveComponentTreeNodes(addedWindowTreeNode, window.getComponents());

		updateCurrentOperationsLabel("New window node added.");				
	}

	@Override
	public void monitoredWindowUpdate(final String hash) 
	{
		if (isInRestrictedList(Integer.valueOf(hash)))
			return;

		// TODO here the check should be different , not be hashCode but with index only
		StringBuffer windowIndex = new StringBuffer();
		Window window = MonitoredWindows.getInstance().getNativeWindow(hash, windowIndex);

		//TODO change this
		if (window.toString().equals("java.awt.Frame[frame0,0,0,132x38,invalid,hidden,layout=java.awt.BorderLayout,title=PopupMessageWindow,resizable,normal]"))
			return;
		
		updateCurrentOperationsLabel("Updating window. Hash: " + hash);
		final ComponentTreeNode componentTreeNode = getComponentTreeNodeByComponent(root, window, false);
		if (componentTreeNode == null)
		{
			// could be in cases such parent is : javax.swing.SwingUtilities$SharedOwnerFrame
			return;
		}
		updateCurrentOperationsLabel("Updating window. description: " + componentTreeNode.getUserObject());
		String newDescription = componentTreeNode.getNodeDescription(window, Integer.parseInt(windowIndex.toString()));

		if (! componentTreeNode.getNodeDescription().toString().equals(newDescription))
		{
			componentTreeNode.setNodeDescription(newDescription);
		}

		addUpdateRemoveComponentTreeNodes(componentTreeNode, window.getComponents());
		updateCurrentOperationsLabel("Updating window is done. Hash: " + hash);				
	}

	private void updateCurrentOperationsLabel(final String line)
	{
		SwingUtils.invoke(new Runnable() {

			@Override
			public void run() {
				currentOperationLabel.setText(line);
			}
		});	
	}

	private void addUpdateRemoveComponentTreeNodes(ComponentTreeNode parentNode, Component[] components)
	{
		List thisNodeChilds = new ArrayList();
		updateCurrentOperationsLabel("Updating " + components.length + " components.");

		int componentIndex = 0;
		for (Component component : components)
		{						
			ComponentTreeNode node = parentNode.getComponentTreeNodeByComponent(component, componentIndex);
			if (node == null)
			{
				node = addComponentTreeNode(parentNode, component, componentIndex);
				updateCurrentOperationsLabel("Node created. description: " + node.getUserObject());
			}

			thisNodeChilds.add(node.getUserObject());

			if (component instanceof Container)  {
				Container subContainer = (Container)component;
				addUpdateRemoveComponentTreeNodes(node, subContainer.getComponents());
			}else{
				JavaApplication1.writeToLog("not updating sub component of : " + component.getClass().getName().toString());
			}	

			componentIndex = componentIndex + 1;
		}    			

		removeComponentTreeNode(parentNode, thisNodeChilds);								
	}

	private void removeComponentTreeNode(ComponentTreeNode parentNode, List thisNodeChilds)
	{
		updateCurrentOperationsLabel("Searching for old nodes to remove...");

		Enumeration e = parentNode.children();
		while(e.hasMoreElements())
		{							
			boolean found = false;
			final ComponentTreeNode node = (ComponentTreeNode) e.nextElement();
			for (Object nodeChild : thisNodeChilds)
			{
				if (node.getUserObject().equals(nodeChild))
				{
					found = true;
					break;
				}				
			}		
			if (! found)
			{
				updateCurrentOperationsLabel("Removing node. Description: " + node.getUserObject());

				SwingUtils.invoke(new Runnable() {

					@Override
					public void run() {
						if (node.getParent() != null)
							treeModel.removeNodeFromParent(node);

					}
				});				
			}
		}			
	}

	private ComponentTreeNode addComponentTreeNode(final ComponentTreeNode parentNode, Component component, int componentIndex)
	{
		final ComponentTreeNode addedComponentTreeNode = new ComponentTreeNode(component, componentIndex);

		SwingUtils.invoke(new Runnable() {

			@Override
			public void run() {
				treeModel.insertNodeInto(addedComponentTreeNode, parentNode, parentNode.getChildCount());				
			}
		});

		return addedComponentTreeNode;
	}

	@Override
	public void monitoredWindowRemoved(String hash)
	{        		
		if (isInRestrictedList(Integer.valueOf(hash)))
			return;

		updateCurrentOperationsLabel("Window closed. hash: " + hash);

		final ComponentTreeNode node = getComponentTreeNodeByComponentByHashCode(root, Integer.valueOf(hash));
		updateCurrentOperationsLabel("Removing node with description: " + node.getUserObject());

		SwingUtils.invoke(new Runnable() {

			@Override
			public void run() {
				treeModel.removeNodeFromParent(node);				
			}
		});

		updateCurrentOperationsLabel("Node removed. hash : " + hash);		    
	}

	@Override
	public void monitoredWindowCycleStarted() 
	{
		listenToInputEvents = false;
		executeSyncOnNextTimer = false;
	}

	@Override
	public void monitoredWindowCycleFinished() 
	{
		listenToInputEvents = true;		
		executeSyncOnNextTimer = true;
	}       

	public void setInspectionTree(javax.swing.JTree inspectionTree) {
		this.inspectionTree = inspectionTree;
	}

	public javax.swing.JTree getInspectionTree() {
		return inspectionTree;
	}

	public void registerForMonitoredEventsNotifictions(MonitoredEventsListener listener)
	{
		monitoredEventsListener.add(listener);
	}

	public void monitoredMouseEvent(TreePath treePath, AWTEvent event, int delay)
	{    	
		for (MonitoredEventsListener listener : monitoredEventsListener)
		{
			listener.monitoredMouse(treePath, event, delay);
		}
	}

	public void monitoreKeyboardEvent(TreePath treePath, AWTEvent event, int delay)
	{    	
		for (MonitoredEventsListener listener : monitoredEventsListener)
		{
			listener.monitoredKeyboard(treePath, event, delay);
		}
	}


	class InspectionTreeModelListener implements TreeModelListener 
	{		
		@Override
		public void treeNodesChanged(TreeModelEvent e) {
			DefaultMutableTreeNode node;
			node = (DefaultMutableTreeNode)(e.getTreePath().getLastPathComponent());

			/*
			 * If the event lists children, then the changed
			 * node is the child of the node we've already
			 * gotten.  Otherwise, the changed node and the
			 * specified node are the same.
			 */

			int index = e.getChildIndices()[0];
			node = (DefaultMutableTreeNode)(node.getChildAt(index));

			System.out.println("The user has finished editing the node.");
			System.out.println("New value: " + node.getUserObject());
		}

		@Override
		public void treeNodesInserted(TreeModelEvent e) 
		{
			for (Object child : e.getChildren())
			{
				final DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) child;
				final DefaultMutableTreeNode treeParentNode = (DefaultMutableTreeNode) e.getPath()[e.getPath().length-1];

				SwingUtils.invoke(new Runnable() {

					@Override
					public void run() {
						model.addElement("Child: " + treeNode.getUserObject() + " , Parent: " + treeParentNode.getUserObject() + " added");
					}
				});

			}
		}

		@Override
		public void treeNodesRemoved(TreeModelEvent e) 
		{
			for (Object child : e.getChildren())
			{
				final DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) child;
				final DefaultMutableTreeNode treeParentNode = (DefaultMutableTreeNode) e.getPath()[e.getPath().length-1];

				SwingUtils.invoke(new Runnable() {

					@Override
					public void run() {
						model.addElement("Child: " + treeNode.getUserObject() + " , Parent: " + treeParentNode.getUserObject() + " removed");
					}
				});				
			}
		}

		@Override
		public void treeStructureChanged(TreeModelEvent e) 
		{
		}
	}

	public void hardStop()
	{
		//TODO deadlock ahead
		// if SwingUtils invoke will be to wait
		// this will hang
		while (currentlySyncing)
		{
			JavaApplication1.writeToLog("coming to a complete hard stop...");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		listenToInputEvents = false;
		stopSync = true;
	}

	public void hardStart()
	{
		listenToInputEvents = true;
		stopSync = false;
	}

	@Override
	public void monitoredWindowRestored(WindowEvent e) {		
		for (MonitoredEventsListener listener : monitoredEventsListener)
		{
			listener.monitoredWindowRestored(e);
		}		
	}

	@Override
	public void monitoredWindowMinimized(WindowEvent e) {	
		for (MonitoredEventsListener listener : monitoredEventsListener)
		{
			listener.monitoredWindowMinimized(e);
		}
	}

	@Override
	public void monitoredWindowMaximized(WindowEvent e) {		
		for (MonitoredEventsListener listener : monitoredEventsListener)
		{
			listener.monitoredWindowMaximized(e);
		}
	}

	public ComponentTreeNode getRoot() {
		return root;
	}

	public boolean isListenToInputEvents() {
		return listenToInputEvents;
	}

	public void setListenToInputEvents(boolean listenToInputEvents) {
		this.listenToInputEvents = listenToInputEvents;

		if (! isListenToInputEvents())
			SwingUtils.invoke(new Runnable()
			{
				@Override
				public void run()
				{
					updateCurrentOperationsLabel("Not listening to input events. e.g.: Keyboard, Mouse...");
					highlightSelectedNode.setSelected(false);
					highlightSelectedNode.setEnabled(false);
				}
			});
		else
			SwingUtils.invoke(new Runnable()
			{
				@Override
				public void run()
				{
					updateCurrentOperationsLabel("listening to input events. e.g.: Keyboard, Mouse...");
					highlightSelectedNode.setEnabled(true);
				}
			});
	}


}
