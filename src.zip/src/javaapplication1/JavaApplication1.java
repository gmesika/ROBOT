/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;


import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.EventHandler;
import java.security.Permission;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author GUYMES
 */
public class JavaApplication1 {
    
    /**
     * @param args the command line arguments
     */
	static volatile boolean keepRunning = true;
    public static void main(String[] args) {
        // TODO code application logic here
        
        launchMyForm();
        //MockingController.main(args);
        //NewJFrame.main(args);
       launchOrdering(args);

    }
    
    private static void launchMyForm()
    {
        Inspector X = new Inspector();
        
        //MockingController y = new MockingController();
        
       // X.show();        
       
    }
    
    public static void writeToLog(String line)
    {
    	System.out.println(line);
    }
    
    private static void launchOrdering(String[] args)
    {
        try {
            com.amdocs.uif.workspace.Main x = new com.amdocs.uif.workspace.Main();
        x.main(args);
        } catch (Exception e) {
            String toString = System.console().toString();
                  
        }
            
            
        
    }
    
    
}
//
//class SystemExitControl {
//	 
//    public static class ExitTrappedException extends SecurityException {
//    }
// 
//    public static void forbidSystemExitCall() {
//        final SecurityManager securityManager = new SecurityManager() {
//            @Override
//            public void checkPermission(Permission permission) {
//                if (permission.getName().contains("exitVM")) {
//                    //throw new ExitTrappedException();
//                	System.out.println("ss");
//                }
//            }
//            
//        };
//        System.setSecurityManager(securityManager);
//    }
// 
//    public static void enableSystemExitCall() {
//        System.setSecurityManager(null);
//    }
//}