/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Calendar;
import java.util.List;
import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.MenuElement;

import oracle.jrockit.jfr.events.JavaProducerDescriptor;

/**
 *
 * @author GUYMES
 */
public class MonitoredWindows
{    
    private static MonitoredWindows monitoredWindows;
        
    private final List<MonitoredWindowListener> listeners = new ArrayList<MonitoredWindowListener>();
    
    private long syncLastRunningTime = 0;
    
    public static MonitoredWindows getInstance()
    {
        if (monitoredWindows == null)
        {
            monitoredWindows = new MonitoredWindows();
        }
        
        return monitoredWindows;
    }
    
    private List m_monitoredWindows;
    
    public synchronized List getWindows()
    {
        if (m_monitoredWindows == null)
        {
            m_monitoredWindows = new ArrayList();    
        }
                
        return m_monitoredWindows;
    }   
    
    public void registerForWindowsNotifictions(MonitoredWindowListener listener)
    {
        listeners.add (listener);
    }
    
    private void AddListenerToWindow(Window window)
    {    	    
    	window.addWindowStateListener(new WindowStateListener() {
			
			@Override
			public void windowStateChanged(WindowEvent e) {

				JavaApplication1.writeToLog(e.toString());
				
				switch (e.getID())
				{
				case WindowEvent.WINDOW_ACTIVATED:				
					{break;}
				case WindowEvent.WINDOW_CLOSED:			
					{break;}
				case WindowEvent.WINDOW_CLOSING:				
				{break;}
				case WindowEvent.WINDOW_DEACTIVATED:				
				{break;}
				case WindowEvent.WINDOW_DEICONIFIED:				
				{break;}
//				case WindowEvent.WINDOW_FIRST:				
//				{break;}
				case WindowEvent.WINDOW_GAINED_FOCUS:				
				{break;}
				case WindowEvent.WINDOW_ICONIFIED:				
				{break;}
//				case WindowEvent.WINDOW_LAST:				
//				{break;}
				case WindowEvent.WINDOW_LOST_FOCUS:				
				{break;}
				case WindowEvent.WINDOW_OPENED:				
				{break;}
				case WindowEvent.WINDOW_STATE_CHANGED:				
				{
					if (e.getNewState() == 0)
					{
						monitoredWindowRestoredEvent(e);
					}
					if (e.getNewState() == 1)
					{
						monitoredWindowMinimazedEvent(e);
					}
					if (e.getNewState() == 6)
					{
						monitoredWindowMaximizedEvent(e);
					}
					break;
				}
				}
			}
		});
    }
    
    public synchronized void syncWindows()
    {
    	monitoredWindowCycleStartedEvent();
    	
        Window[] windows = Window.getWindows();
        List currentWindows = new ArrayList();
        List currentlyAddedWindows = new ArrayList();
        
        for (Window window : windows)
        {           
            String hash = String.valueOf(window.hashCode());
            currentWindows.add(hash);
            if (! getWindows().contains(hash))
            {
                getWindows().add(hash);
                monitoredWindowAddedEvent(hash);
                currentlyAddedWindows.add(hash);
                
                AddListenerToWindow(window);
            }           
        }
        
        List removedWindows = new ArrayList();
        
        for (Object hash : getWindows())
        {
            if (! currentWindows.contains(hash))
            {
                // window was closed
                monitoredWindowRemovedEvent((String) hash);
                removedWindows.add(hash);
            }            
            
            if (currentWindows.contains(hash) && ! currentlyAddedWindows.contains(hash)
            		&& ! removedWindows.contains(hash))
            {
                monitoredWindowUpdateEvent((String) hash);
            }
        }
        
        for (Object hash : removedWindows)
        {
        	MonitoredWindows.getInstance().getWindows().remove(hash);
        }         
        
        monitoredWindowCycleFinishedEvent();
        
    }
    
    public void monitoredWindowAddedEvent(String hash)
    {    	
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowAdded(hash);
        }
    }
    
    public void monitoredWindowUpdateEvent(String hash)
    {    	
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowUpdate(hash);
        }
    }
    
    public void monitoredWindowRemovedEvent(String hash)
    {
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowRemoved(hash);
        }
    }

    public void monitoredWindowCycleStartedEvent()
    {
    	//JavaApplication1.writeToLog("Start Thread:" + Thread.currentThread().getId() + " " + Thread.currentThread().getName());
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowCycleStarted();
        }
    }

    public void monitoredWindowCycleFinishedEvent()
    {
    	//JavaApplication1.writeToLog("End Thread:" + Thread.currentThread().getId() + " " + Thread.currentThread().getName());
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowCycleFinished();
        }
        
        syncLastRunningTime = Calendar.getInstance().getTimeInMillis(); 
    }
    
    public void monitoredWindowRestoredEvent(WindowEvent e)
    {
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowRestored(e);
        }
    }
    
    public void monitoredWindowMinimazedEvent(WindowEvent e)
    {
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowMinimized(e);
        }
    }
    
    public void monitoredWindowMaximizedEvent(WindowEvent e)
    {
        for (MonitoredWindowListener listener : listeners)
        {
            listener.monitoredWindowMaximized(e);
        }
    }
    
    public Window getNativeWindow(String hash, StringBuffer windowIndex)
    {
        Window[] windows = Window.getWindows();
        int counter = 0;
        for (Window window : windows)
        {
            if (String.valueOf(window.hashCode()).equals(hash))
            {
            	windowIndex.append(counter);
                return window;
            }
        	counter = counter + 1;
        }
        
        return null;
    }

	public long getSyncLastRunningTime() {
		return syncLastRunningTime;
	}
    
//    public Window getNativeWindow(int windowIndex)
//    {
//        Window[] windows = Window.getWindows();
//        return windows[windowIndex];               
//    }
    
//    public JFrame getNativeJFrameByTitle(String title)
//    {
//        Window[] windows = Window.getWindows();
//        for (Window window : windows)
//        {
//        	if (window instanceof JFrame)
//        	{
//        		if (((JFrame)window).getTitle().equals(title))
//                {
//                    return (JFrame) window;
//                }
//        	}            
//        }
//        
//        return null;
//    }
    
//    public Container getNativeContainer(int hash, int topWindowHashCode)
//    {
//    	Window containersWindow = getNativeWindow(topWindowHashCode);
//    	Component[] components = containersWindow.getComponents();  
//    	return getNativeContainerByHash((Container)components[0], hash);    	
//    }
    
//    public Container getNativeContainer(Window containersWindow, String topWindowHashCode)
//    {
//    	//Window containersWindow = getNativeWindow(topWindowHashCode);
//    	Component[] components = containersWindow.getComponents();  
//    	return getComponentByHash(components[0], hash);    	
//    }
//    
//    public Component getComponentByComponentHashCode(Window window, int componentHashCode)
//    {
//    	Component[] components = window.getComponents();
//    	for (Component component : components)
//    	{
//    		if (component.hashCode() == componentHashCode)
//    		{
//    			return component;
//    		}
//    		
//    	}
//    	
//    	getComponentByHash(window, String hash)
//    }
    
 
       
}
