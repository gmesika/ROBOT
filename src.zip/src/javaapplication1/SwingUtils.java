package javaapplication1;

import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import sun.swing.SwingUtilities2;

public class SwingUtils 
{	
	
	public static void invoke(Runnable runnable)
	{
		if (SwingUtilities.isEventDispatchThread())
		{
			runnable.run();
		}
		else
		{
			invokeAndContiune(runnable);

//			try {
//				SwingUtilities.invokeAndWait(runnable);
//			} catch (InvocationTargetException e) {				
//				e.printStackTrace();
//				JavaApplication1.writeToLog(e.toString());
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//				JavaApplication1.writeToLog(e.toString());
//			}		
		}
		
	}
	
	public static void invokeAndContiune(Runnable runnable)
	{
		if (SwingUtilities.isEventDispatchThread())
		{
			runnable.run();
		}
		else
		{			
			SwingUtilities.invokeLater(runnable);		
		}
		
	}

}
